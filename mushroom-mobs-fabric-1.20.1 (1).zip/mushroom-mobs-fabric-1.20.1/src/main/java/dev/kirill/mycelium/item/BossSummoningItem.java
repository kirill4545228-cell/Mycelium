package dev.kirill.mycelium.item;

import dev.kirill.mycelium.entity.ModEntities;
import dev.kirill.mycelium.entity.MushroomBossEntity;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BossSummoningItem extends Item {
    public BossSummoningItem(Settings settings) { super(settings); }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos clicked = context.getBlockPos();
        boolean valid = world.getBlockState(clicked).isOf(Blocks.MYCELIUM)
                || world.getBlockState(clicked).isOf(Blocks.RED_MUSHROOM_BLOCK)
                || world.getBlockState(clicked).isOf(Blocks.BROWN_MUSHROOM_BLOCK);
        if (!valid) return ActionResult.PASS;
        if (!world.isClient) {
            MushroomBossEntity boss = ModEntities.MUSHROOM_BOSS.create(world);
            if (boss == null) return ActionResult.FAIL;
            boss.refreshPositionAndAngles(clicked.getX() + 0.5, clicked.getY() + 1.0, clicked.getZ() + 0.5, context.getPlayer() == null ? 0 : context.getPlayer().getYaw(), 0);
            if (!world.spawnEntity(boss)) return ActionResult.FAIL;
            if (context.getPlayer() == null || !context.getPlayer().getAbilities().creativeMode) context.getStack().decrement(1);
        }
        return ActionResult.success(world.isClient);
    }
}
