package dev.kirill.mycelium.client.model;

import dev.kirill.mycelium.entity.MushroomBeetleEntity;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class MushroomBeetleModel extends net.minecraft.client.render.entity.model.EntityModel<MushroomBeetleEntity> {
    private final ModelPart root;

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData beetle = root.addChild("beetle", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData body = beetle.addChild("body", ModelPartBuilder.create(), ModelTransform.of(0.00000F, -6.00000F, 2.00000F, 0.00000F, 0.00000F, 0.00000F));
        body.addChild("cube_abdomen", ModelPartBuilder.create().uv(7, 7).cuboid(-3.00000F, -8.00000F, 0.00000F, 6.00000F, 4.00000F, 7.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 6.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        body.addChild("cube_thorax", ModelPartBuilder.create().uv(30, 15).cuboid(-2.50000F, -8.00000F, -4.00000F, 5.00000F, 4.00000F, 4.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 6.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData head = body.addChild("head", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, -6.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_eye_l", ModelPartBuilder.create().uv(37, 34).cuboid(-2.50000F, -7.00000F, -7.50000F, 1.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 6.00000F, 4.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_eye_r", ModelPartBuilder.create().uv(33, 34).cuboid(1.50000F, -7.00000F, -7.50000F, 1.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 6.00000F, 4.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_head", ModelPartBuilder.create().uv(23, 24).cuboid(-2.00000F, -7.50000F, -7.00000F, 4.00000F, 3.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 6.00000F, 4.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData mandible_r = head.addChild("mandible_r", ModelPartBuilder.create(), ModelTransform.of(1.00000F, 0.50000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        mandible_r.addChild("cube_mandible_r", ModelPartBuilder.create().uv(22, 35).cuboid(0.50000F, -6.00000F, -9.00000F, 1.00000F, 1.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(-1.00000F, 5.50000F, 7.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData mandible_l = head.addChild("mandible_l", ModelPartBuilder.create(), ModelTransform.of(-1.00000F, 0.50000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        mandible_l.addChild("cube_mandible_l", ModelPartBuilder.create().uv(28, 35).cuboid(-1.50000F, -6.00000F, -9.00000F, 1.00000F, 1.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(1.00000F, 5.50000F, 7.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData antenna_r = head.addChild("antenna_r", ModelPartBuilder.create(), ModelTransform.of(1.50000F, -1.50000F, -1.50000F, 0.00000F, 0.00000F, 0.00000F));
        antenna_r.addChild("cube_tip_r", ModelPartBuilder.create().uv(3, 32).cuboid(0.00000F, -11.50000F, -7.00000F, 3.00000F, 1.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(-1.50000F, 7.50000F, 5.50000F, 0.00000F, 0.00000F, 0.00000F));
        antenna_r.addChild("cube_stalk_r", ModelPartBuilder.create().uv(59, 22).cuboid(1.00000F, -10.50000F, -6.00000F, 1.00000F, 3.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-1.50000F, 7.50000F, 5.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData antenna_l = head.addChild("antenna_l", ModelPartBuilder.create(), ModelTransform.of(-1.50000F, -1.50000F, -1.50000F, 0.00000F, 0.00000F, 0.00000F));
        antenna_l.addChild("cube_tip_l", ModelPartBuilder.create().uv(19, 32).cuboid(-3.00000F, -11.50000F, -7.00000F, 3.00000F, 1.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(1.50000F, 7.50000F, 5.50000F, 0.00000F, 0.00000F, 0.00000F));
        antenna_l.addChild("cube_stalk_l", ModelPartBuilder.create().uv(13, 30).cuboid(-2.00000F, -10.50000F, -6.00000F, 1.00000F, 3.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(1.50000F, 7.50000F, 5.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData elytra_r = body.addChild("elytra_r", ModelPartBuilder.create(), ModelTransform.of(0.50000F, -3.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        elytra_r.addChild("cube_shell_up_r", ModelPartBuilder.create().uv(51, 18).cuboid(0.00000F, -11.00000F, -2.00000F, 3.00000F, 1.00000F, 7.00000F, Dilation.NONE), ModelTransform.of(-0.50000F, 9.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        elytra_r.addChild("cube_shell_low_r", ModelPartBuilder.create().uv(35, 9).cuboid(0.00000F, -10.00000F, -3.00000F, 4.00000F, 1.00000F, 9.00000F, Dilation.NONE), ModelTransform.of(-0.50000F, 9.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData elytra_l = body.addChild("elytra_l", ModelPartBuilder.create(), ModelTransform.of(-0.50000F, -3.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        elytra_l.addChild("cube_shell_up_l", ModelPartBuilder.create().uv(7, 28).cuboid(-3.00000F, -11.00000F, -2.00000F, 3.00000F, 1.00000F, 7.00000F, Dilation.NONE), ModelTransform.of(0.50000F, 9.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        elytra_l.addChild("cube_shell_low_l", ModelPartBuilder.create().uv(9, 20).cuboid(-4.00000F, -10.00000F, -3.00000F, 4.00000F, 1.00000F, 9.00000F, Dilation.NONE), ModelTransform.of(0.50000F, 9.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData wing_r = body.addChild("wing_r", ModelPartBuilder.create(), ModelTransform.of(3.00000F, -2.50000F, -3.00000F, 0.00000F, -1.57080F, 0.00000F));
        wing_r.addChild("cube_wing_r", ModelPartBuilder.create().uv(31, 32).cuboid(3.00000F, -9.00000F, -1.00000F, 7.00000F, 1.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 8.50000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData wing_l = body.addChild("wing_l", ModelPartBuilder.create(), ModelTransform.of(-3.00000F, -2.50000F, -3.00000F, 0.00000F, 1.57080F, 0.00000F));
        wing_l.addChild("cube_wing_l", ModelPartBuilder.create().uv(3, 36).cuboid(-10.00000F, -9.00000F, -1.00000F, 7.00000F, 1.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 8.50000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_fr = body.addChild("leg_fr", ModelPartBuilder.create(), ModelTransform.of(3.00000F, 0.50000F, -4.50000F, 0.00000F, 0.00000F, -0.17453F));
        leg_fr.addChild("cube_tibia_fr", ModelPartBuilder.create().uv(35, 22).cuboid(4.00000F, -5.00000F, -3.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, 2.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_fr.addChild("cube_femur_fr", ModelPartBuilder.create().uv(41, 34).cuboid(3.00000F, -6.00000F, -3.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, 2.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_fl = body.addChild("leg_fl", ModelPartBuilder.create(), ModelTransform.of(-3.00000F, 0.50000F, -4.50000F, 0.00000F, 0.00000F, 0.17453F));
        leg_fl.addChild("cube_tibia_fl", ModelPartBuilder.create().uv(39, 22).cuboid(-5.00000F, -5.00000F, -3.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, 2.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_fl.addChild("cube_femur_fl", ModelPartBuilder.create().uv(47, 34).cuboid(-5.00000F, -6.00000F, -3.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, 2.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_mr = body.addChild("leg_mr", ModelPartBuilder.create(), ModelTransform.of(3.00000F, 0.50000F, -1.50000F, 0.00000F, 0.00000F, -0.17453F));
        leg_mr.addChild("cube_tibia_mr", ModelPartBuilder.create().uv(43, 22).cuboid(4.00000F, -5.00000F, 0.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, -0.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_mr.addChild("cube_femur_mr", ModelPartBuilder.create().uv(53, 34).cuboid(3.00000F, -6.00000F, 0.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, -0.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_ml = body.addChild("leg_ml", ModelPartBuilder.create(), ModelTransform.of(-3.00000F, 0.50000F, -1.50000F, 0.00000F, 0.00000F, 0.17453F));
        leg_ml.addChild("cube_tibia_ml", ModelPartBuilder.create().uv(47, 22).cuboid(-5.00000F, -5.00000F, 0.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, -0.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_ml.addChild("cube_femur_ml", ModelPartBuilder.create().uv(59, 34).cuboid(-5.00000F, -6.00000F, 0.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, -0.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_br = body.addChild("leg_br", ModelPartBuilder.create(), ModelTransform.of(3.00000F, 0.50000F, 1.50000F, 0.00000F, 0.00000F, -0.17453F));
        leg_br.addChild("cube_tibia_br", ModelPartBuilder.create().uv(51, 22).cuboid(4.00000F, -5.00000F, 3.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, -3.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_br.addChild("cube_femur_br", ModelPartBuilder.create().uv(1, 38).cuboid(3.00000F, -6.00000F, 3.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(-3.00000F, 5.50000F, -3.50000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_bl = body.addChild("leg_bl", ModelPartBuilder.create(), ModelTransform.of(-3.00000F, 0.50000F, 1.50000F, 0.00000F, 0.00000F, 0.17453F));
        leg_bl.addChild("cube_tibia_bl", ModelPartBuilder.create().uv(55, 22).cuboid(-5.00000F, -5.00000F, 3.00000F, 1.00000F, 5.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, -3.50000F, 0.00000F, 0.00000F, 0.00000F));
        leg_bl.addChild("cube_femur_bl", ModelPartBuilder.create().uv(7, 38).cuboid(-5.00000F, -6.00000F, 3.00000F, 2.00000F, 1.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(3.00000F, 5.50000F, -3.50000F, 0.00000F, 0.00000F, 0.00000F));
        return TexturedModelData.of(modelData, 64, 64);
    }

    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart wing_r;
    private final ModelPart wing_l;
    private final ModelPart elytra_r;
    private final ModelPart elytra_l;
    private final ModelPart leg_fr;
    private final ModelPart leg_fl;
    private final ModelPart leg_mr;
    private final ModelPart leg_ml;
    private final ModelPart leg_br;
    private final ModelPart leg_bl;
    private final ModelPart antenna_r;
    private final ModelPart antenna_l;
    private final ModelPart mandible_r;
    private final ModelPart mandible_l;
    public MushroomBeetleModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("beetle").getChild("body");
        this.head = root.getChild("beetle").getChild("body").getChild("head");
        this.wing_r = root.getChild("beetle").getChild("body").getChild("wing_r");
        this.wing_l = root.getChild("beetle").getChild("body").getChild("wing_l");
        this.elytra_r = root.getChild("beetle").getChild("body").getChild("elytra_r");
        this.elytra_l = root.getChild("beetle").getChild("body").getChild("elytra_l");
        this.leg_fr = root.getChild("beetle").getChild("body").getChild("leg_fr");
        this.leg_fl = root.getChild("beetle").getChild("body").getChild("leg_fl");
        this.leg_mr = root.getChild("beetle").getChild("body").getChild("leg_mr");
        this.leg_ml = root.getChild("beetle").getChild("body").getChild("leg_ml");
        this.leg_br = root.getChild("beetle").getChild("body").getChild("leg_br");
        this.leg_bl = root.getChild("beetle").getChild("body").getChild("leg_bl");
        this.antenna_r = root.getChild("beetle").getChild("body").getChild("head").getChild("antenna_r");
        this.antenna_l = root.getChild("beetle").getChild("body").getChild("head").getChild("antenna_l");
        this.mandible_r = root.getChild("beetle").getChild("body").getChild("head").getChild("mandible_r");
        this.mandible_l = root.getChild("beetle").getChild("body").getChild("head").getChild("mandible_l");
    }


    @Override public void setAngles(MushroomBeetleEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        float walk = limbDistance;
        float swing = MathHelper.cos(limbAngle * 0.9F) * 0.60F * walk;
        this.leg_fr.pitch = swing; this.leg_bl.pitch = swing; this.leg_mr.pitch = -swing;
        this.leg_fl.pitch = -swing; this.leg_br.pitch = -swing; this.leg_ml.pitch = swing;
        this.head.yaw = headYaw * 0.017453292F; this.head.pitch = headPitch * 0.017453292F + MathHelper.sin(animationProgress * 0.08F) * 0.04F;
        float flutter = 0.12F + MathHelper.sin(animationProgress * 1.9F) * 0.18F;
        this.wing_r.roll = flutter; this.wing_l.roll = -flutter;
        this.elytra_r.roll = 0.08F + MathHelper.sin(animationProgress * 0.7F) * 0.035F; this.elytra_l.roll = -this.elytra_r.roll;
        this.antenna_r.roll = MathHelper.sin(animationProgress * 0.11F) * 0.10F; this.antenna_l.roll = -this.antenna_r.roll;
        this.mandible_r.pitch = MathHelper.sin(animationProgress * 0.13F) * 0.04F; this.mandible_l.pitch = -this.mandible_r.pitch;
    }

    @Override public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
        this.root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
