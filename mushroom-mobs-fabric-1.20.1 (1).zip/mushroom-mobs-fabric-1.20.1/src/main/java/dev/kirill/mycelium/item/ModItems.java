package dev.kirill.mycelium.item;

import dev.kirill.mycelium.MyceliumMod;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item MUSHROOM_SWORD = register("mushroom_sword", new MushroomSwordItem(new Item.Settings().fireproof()));
    public static final Item MUSHROOM_SPORE = register("mushroom_spore", new Item(new Item.Settings().maxCount(64)));
    public static final Item BEETLE_CHITIN = register("beetle_chitin", new Item(new Item.Settings().maxCount(64)));
    public static final Item BEETLE_SHELL = register("beetle_shell", new Item(new Item.Settings().maxCount(16)));
    public static final Item SPORE_CORE = register("spore_core", new Item(new Item.Settings().maxCount(16)));
    public static final Item CROWN_FRAGMENT = register("crown_fragment", new Item(new Item.Settings().maxCount(16)));
    public static final Item AWAKENING_HEART = register("awakening_heart", new BossSummoningItem(new Item.Settings().maxCount(16).fireproof()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MyceliumMod.MOD_ID, name), item);
    }
    public static void initialize() {
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.item.ItemGroups.COMBAT)
                .register(entries -> entries.add(MUSHROOM_SWORD));
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(net.minecraft.item.ItemGroups.INGREDIENTS)
                .register(entries -> {
                    entries.add(MUSHROOM_SPORE);
                    entries.add(BEETLE_CHITIN);
                    entries.add(BEETLE_SHELL);
                    entries.add(SPORE_CORE);
                    entries.add(CROWN_FRAGMENT);
                    entries.add(AWAKENING_HEART);
                });
    }
    private ModItems() { }
}
