package dev.kirill.mycelium;

import dev.kirill.mycelium.entity.ModEntities;
import dev.kirill.mycelium.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyceliumMod implements ModInitializer {
    public static final String MOD_ID = "mycelium";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModEntities.initialize();
        ModEntities.registerAttributes();
        ModEntities.registerSpawns();
        LOGGER.info("Mycelium Mobs loaded");
    }
}
