package dev.kirill.mycelium.client;

import dev.kirill.mycelium.MyceliumMod;
import dev.kirill.mycelium.client.model.MushroomBeetleModel;
import dev.kirill.mycelium.client.model.MushroomBossModel;
import dev.kirill.mycelium.client.render.MushroomBeetleRenderer;
import dev.kirill.mycelium.client.render.MushroomBossRenderer;
import dev.kirill.mycelium.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class MyceliumClient implements ClientModInitializer {
    public static final EntityModelLayer BEETLE_LAYER = new EntityModelLayer(new Identifier(MyceliumMod.MOD_ID, "mushroom_beetle"), "main");
    public static final EntityModelLayer BOSS_LAYER = new EntityModelLayer(new Identifier(MyceliumMod.MOD_ID, "mushroom_boss"), "main");

    @Override public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(BEETLE_LAYER, MushroomBeetleModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(BOSS_LAYER, MushroomBossModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.MUSHROOM_BEETLE, MushroomBeetleRenderer::new);
        EntityRendererRegistry.register(ModEntities.MUSHROOM_BOSS, MushroomBossRenderer::new);
    }
}
