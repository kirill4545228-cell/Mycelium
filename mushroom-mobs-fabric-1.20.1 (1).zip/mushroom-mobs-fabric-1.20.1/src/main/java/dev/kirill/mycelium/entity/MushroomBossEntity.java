package dev.kirill.mycelium.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

public class MushroomBossEntity extends HostileEntity {
    private static final TrackedData<Integer> SLAM_TICKS = DataTracker.registerData(MushroomBossEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private int slamCooldown;
    private int roarCooldown = 180;

    public MushroomBossEntity(EntityType<? extends HostileEntity> type, World world) { super(type, world); }

    @Override protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(SLAM_TICKS, 0);
    }

    public int getSlamTicks() { return this.dataTracker.get(SLAM_TICKS); }
    public boolean isEnraged() { return this.getHealth() <= this.getMaxHealth() * 0.5F; }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 180.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.23)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.75);
    }

    @Override protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 0.92, true));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.65));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 12.0F));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;
        if (slamCooldown > 0) slamCooldown--;
        int remaining = getSlamTicks();
        if (remaining > 0) {
            this.getNavigation().stop();
            if (remaining == 6) performSlam();
            this.dataTracker.set(SLAM_TICKS, remaining - 1);
        } else {
            LivingEntity target = this.getTarget();
            double range = isEnraged() ? 5.5 : 4.7;
            if (target != null && this.squaredDistanceTo(target) <= range * range && slamCooldown <= 0) {
                this.dataTracker.set(SLAM_TICKS, 24);
                slamCooldown = isEnraged() ? 95 : 130;
            }
        }
        if (roarCooldown > 0) roarCooldown--;
        if (isEnraged() && roarCooldown <= 0 && this.getTarget() != null && this.squaredDistanceTo(this.getTarget()) < 100) {
            performSporeRoar();
            roarCooldown = 220;
        }
    }

    private void performSlam() {
        double radius = isEnraged() ? 6.0 : 5.0;
        float damage = isEnraged() ? 15.0F : 10.0F;
        for (Entity entity : this.getWorld().getOtherEntities(this, this.getBoundingBox().expand(radius), e -> e instanceof LivingEntity && e != this)) {
            if (entity instanceof LivingEntity living && this.squaredDistanceTo(living) <= radius * radius) {
                living.damage(this.getDamageSources().mobAttack(this), damage);
                living.takeKnockback(1.15, this.getX() - living.getX(), this.getZ() - living.getZ());
            }
        }
        if (this.getWorld() instanceof ServerWorld sw) sw.spawnParticles(ParticleTypes.POOF, getX(), getY() + 0.3, getZ(), 32, 1.3, 0.2, 1.3, 0.08);
    }

    private void performSporeRoar() {
        if (this.getWorld() instanceof ServerWorld sw) sw.spawnParticles(ParticleTypes.POOF, getX(), getBodyY(0.8), getZ(), 48, 1.8, 0.8, 1.8, 0.06);
        for (Entity entity : this.getWorld().getOtherEntities(this, this.getBoundingBox().expand(8.0), e -> e instanceof LivingEntity && e != this)) {
            if (entity instanceof LivingEntity living && this.squaredDistanceTo(living) <= 64.0) {
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 0), this);
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), this);
            }
        }
        this.heal(8.0F);
    }

    @Override public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living && isEnraged()) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 80, 0), this);
        }
        return hit;
    }
}
