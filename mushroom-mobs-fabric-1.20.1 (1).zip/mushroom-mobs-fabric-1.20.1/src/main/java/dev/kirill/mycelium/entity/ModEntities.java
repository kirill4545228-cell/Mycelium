package dev.kirill.mycelium.entity;

import dev.kirill.mycelium.MyceliumMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;

public final class ModEntities {
    public static final EntityType<MushroomBeetleEntity> MUSHROOM_BEETLE = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MyceliumMod.MOD_ID, "mushroom_beetle"),
            EntityType.Builder.create(MushroomBeetleEntity::new, SpawnGroup.MONSTER).dimensions(1.0F, 0.85F).maxTrackingRange(10).build("mushroom_beetle"));

    public static final EntityType<MushroomBossEntity> MUSHROOM_BOSS = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MyceliumMod.MOD_ID, "mushroom_boss"),
            EntityType.Builder.create(MushroomBossEntity::new, SpawnGroup.MONSTER).dimensions(2.7F, 3.35F).maxTrackingRange(12).build("mushroom_boss"));

    public static void initialize() { }
    public static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(MUSHROOM_BEETLE, MushroomBeetleEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MUSHROOM_BOSS, MushroomBossEntity.createAttributes());
    }
    public static void registerSpawns() {
        var forestAndMushroomBiomes = BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST, BiomeKeys.MUSHROOM_FIELDS);
        BiomeModifications.addSpawn(forestAndMushroomBiomes, SpawnGroup.MONSTER, MUSHROOM_BEETLE, 35, 1, 3);
        BiomeModifications.addSpawn(forestAndMushroomBiomes, SpawnGroup.MONSTER, MUSHROOM_BOSS, 1, 1, 1);
    }
    private ModEntities() { }
}
