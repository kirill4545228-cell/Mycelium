package dev.kirill.mycelium.client.model;

import dev.kirill.mycelium.entity.MushroomBossEntity;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class MushroomBossModel extends net.minecraft.client.render.entity.model.EntityModel<MushroomBossEntity> {
    private final ModelPart root;

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData boss = root.addChild("boss", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, -6.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData body = boss.addChild("body", ModelPartBuilder.create(), ModelTransform.of(0.00000F, -19.00000F, 9.00000F, 0.00000F, 0.00000F, 0.00000F));
        body.addChild("cube_pelvis", ModelPartBuilder.create().uv(128, 70).cuboid(-8.00000F, -22.00000F, -3.00000F, 16.00000F, 6.00000F, 12.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 19.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData chest = body.addChild("chest", ModelPartBuilder.create(), ModelTransform.of(0.00000F, -4.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        chest.addChild("cube_neck", ModelPartBuilder.create().uv(94, 101).cuboid(-6.00000F, -36.00000F, -2.00000F, 12.00000F, 4.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 23.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        chest.addChild("cube_chest", ModelPartBuilder.create().uv(118, 45).cuboid(-11.00000F, -32.00000F, -4.00000F, 22.00000F, 10.00000F, 14.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 23.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData head = chest.addChild("head", ModelPartBuilder.create(), ModelTransform.of(0.00000F, -13.00000F, -4.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_fang_4", ModelPartBuilder.create().uv(157, 117).cuboid(3.00000F, -36.00000F, -9.00000F, 1.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_fang_3", ModelPartBuilder.create().uv(153, 117).cuboid(1.00000F, -36.00000F, -9.00000F, 1.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_fang_2", ModelPartBuilder.create().uv(149, 117).cuboid(-2.00000F, -36.00000F, -9.00000F, 1.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_fang_1", ModelPartBuilder.create().uv(145, 117).cuboid(-4.00000F, -36.00000F, -9.00000F, 1.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_brow_l", ModelPartBuilder.create().uv(130, 118).cuboid(-3.00000F, -0.50000F, -1.00000F, 6.00000F, 1.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(-4.50000F, -6.50000F, -8.50000F, 0.00000F, 0.00000F, 0.34907F));
        head.addChild("cube_brow_r", ModelPartBuilder.create().uv(114, 118).cuboid(-3.00000F, -0.50000F, -1.00000F, 6.00000F, 1.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(4.50000F, -6.50000F, -8.50000F, 0.00000F, 0.00000F, -0.34907F));
        head.addChild("cube_eye_l", ModelPartBuilder.create().uv(103, 117).cuboid(-6.00000F, -42.00000F, -10.00000F, 4.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_eye_r", ModelPartBuilder.create().uv(93, 117).cuboid(2.00000F, -42.00000F, -10.00000F, 4.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        head.addChild("cube_head", ModelPartBuilder.create().uv(12, 70).cuboid(-7.00000F, -44.00000F, -9.00000F, 14.00000F, 8.00000F, 12.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, 1.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData jaw = head.addChild("jaw", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 3.00000F, 0.00000F, 0.00000F, 0.00000F));
        jaw.addChild("cube_tusk_l", ModelPartBuilder.create().uv(222, 110).cuboid(-6.00000F, -39.00000F, -10.00000F, 2.00000F, 4.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        jaw.addChild("cube_tusk_r", ModelPartBuilder.create().uv(214, 110).cuboid(4.00000F, -39.00000F, -10.00000F, 2.00000F, 4.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        jaw.addChild("cube_jaw", ModelPartBuilder.create().uv(10, 105).cuboid(-6.00000F, -36.00000F, -8.00000F, 12.00000F, 3.00000F, 10.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 36.00000F, -2.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData cap = head.addChild("cap", ModelPartBuilder.create(), ModelTransform.of(0.00000F, -8.00000F, 2.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_fringe_l", ModelPartBuilder.create().uv(204, 26).cuboid(-17.00000F, -44.00000F, -12.00000F, 1.00000F, 2.00000F, 26.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_fringe_r", ModelPartBuilder.create().uv(150, 26).cuboid(16.00000F, -44.00000F, -12.00000F, 1.00000F, 2.00000F, 26.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_fringe_b", ModelPartBuilder.create().uv(1, 122).cuboid(-16.00000F, -44.00000F, 14.00000F, 32.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_fringe_f", ModelPartBuilder.create().uv(161, 117).cuboid(-16.00000F, -44.00000F, -13.00000F, 32.00000F, 2.00000F, 1.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_mini2_cap", ModelPartBuilder.create().uv(6, 114).cuboid(-18.50000F, -52.00000F, 4.00000F, 6.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_mini2_stalk", ModelPartBuilder.create().uv(238, 110).cuboid(-16.50000F, -50.00000F, 6.00000F, 2.00000F, 3.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_mini1_cap", ModelPartBuilder.create().uv(234, 101).cuboid(12.50000F, -52.00000F, -10.00000F, 6.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_mini1_stalk", ModelPartBuilder.create().uv(230, 110).cuboid(14.50000F, -50.00000F, -8.00000F, 2.00000F, 3.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_crown_cap", ModelPartBuilder.create().uv(132, 103).cuboid(-4.00000F, -61.00000F, -3.00000F, 8.00000F, 2.00000F, 8.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_crown_stalk", ModelPartBuilder.create().uv(203, 111).cuboid(-1.50000F, -59.00000F, -0.50000F, 3.00000F, 4.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_cap_l4", ModelPartBuilder.create().uv(54, 105).cuboid(-6.00000F, -55.00000F, -4.00000F, 12.00000F, 2.00000F, 10.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_cap_l3", ModelPartBuilder.create().uv(194, 49).cuboid(-10.00000F, -53.00000F, -8.00000F, 20.00000F, 3.00000F, 18.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_cap_l2", ModelPartBuilder.create().uv(24, 55).cuboid(-14.00000F, -50.00000F, -11.00000F, 28.00000F, 3.00000F, 24.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        cap.addChild("cube_cap_brim", ModelPartBuilder.create().uv(28, 28).cuboid(-17.00000F, -47.00000F, -13.00000F, 34.00000F, 3.00000F, 28.00000F, Dilation.NONE), ModelTransform.of(0.00000F, 44.00000F, -1.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData arm_r = chest.addChild("arm_r", ModelPartBuilder.create(), ModelTransform.of(15.00000F, -7.00000F, 0.00000F, 0.00000F, 0.00000F, -0.10472F));
        arm_r.addChild("cube_sh_cap_r", ModelPartBuilder.create().uv(30, 114).cuboid(12.00000F, -37.00000F, 1.00000F, 6.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        arm_r.addChild("cube_sh_stalk_r", ModelPartBuilder.create().uv(246, 110).cuboid(14.00000F, -35.00000F, 2.00000F, 2.00000F, 3.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        arm_r.addChild("cube_uparm_r", ModelPartBuilder.create().uv(60, 66).cuboid(11.00000F, -32.00000F, -1.00000F, 8.00000F, 12.00000F, 8.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData forearm_r = arm_r.addChild("forearm_r", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 9.00000F, 0.00000F, -0.34907F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_elbow_r", ModelPartBuilder.create().uv(70, 118).cuboid(18.50000F, -21.00000F, 2.00000F, 4.00000F, 2.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_spike3_r", ModelPartBuilder.create().uv(51, 119).cuboid(17.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_spike2_r", ModelPartBuilder.create().uv(31, 119).cuboid(14.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_spike1_r", ModelPartBuilder.create().uv(11, 119).cuboid(11.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_fist_r", ModelPartBuilder.create().uv(182, 68).cuboid(10.00000F, -11.00000F, -2.00000F, 10.00000F, 8.00000F, 10.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_r.addChild("cube_forearm_r", ModelPartBuilder.create().uv(7, 85).cuboid(11.50000F, -21.00000F, -0.50000F, 7.00000F, 10.00000F, 7.00000F, Dilation.NONE), ModelTransform.of(-15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData arm_l = chest.addChild("arm_l", ModelPartBuilder.create(), ModelTransform.of(-15.00000F, -7.00000F, 0.00000F, 0.00000F, 0.00000F, 0.10472F));
        arm_l.addChild("cube_sh_cap_l", ModelPartBuilder.create().uv(54, 114).cuboid(-18.00000F, -37.00000F, 1.00000F, 6.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        arm_l.addChild("cube_sh_stalk_l", ModelPartBuilder.create().uv(2, 118).cuboid(-16.00000F, -35.00000F, 2.00000F, 2.00000F, 3.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        arm_l.addChild("cube_uparm_l", ModelPartBuilder.create().uv(92, 66).cuboid(-19.00000F, -32.00000F, -1.00000F, 8.00000F, 12.00000F, 8.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 30.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData forearm_l = arm_l.addChild("forearm_l", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 9.00000F, 0.00000F, -0.34907F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_elbow_l", ModelPartBuilder.create().uv(82, 118).cuboid(-22.50000F, -21.00000F, 2.00000F, 4.00000F, 2.00000F, 2.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_spike3_l", ModelPartBuilder.create().uv(61, 119).cuboid(-19.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_spike2_l", ModelPartBuilder.create().uv(41, 119).cuboid(-16.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_spike1_l", ModelPartBuilder.create().uv(21, 119).cuboid(-13.00000F, -8.00000F, -5.00000F, 2.00000F, 2.00000F, 3.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_fist_l", ModelPartBuilder.create().uv(222, 68).cuboid(-20.00000F, -11.00000F, -2.00000F, 10.00000F, 8.00000F, 10.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        forearm_l.addChild("cube_forearm_l", ModelPartBuilder.create().uv(35, 85).cuboid(-18.50000F, -21.00000F, -0.50000F, 7.00000F, 10.00000F, 7.00000F, Dilation.NONE), ModelTransform.of(15.00000F, 21.00000F, -3.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_1 = chest.addChild("tendril_1", ModelPartBuilder.create(), ModelTransform.of(5.00000F, -6.00000F, 7.00000F, -0.20944F, 0.00000F, 0.00000F));
        tendril_1.addChild("cube_tend1_a", ModelPartBuilder.create().uv(162, 101).cuboid(3.50000F, -30.50000F, 10.00000F, 3.00000F, 3.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-5.00000F, 29.00000F, -10.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_1b = tendril_1.addChild("tendril_1b", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 6.00000F, -0.26180F, 0.00000F, 0.00000F));
        tendril_1b.addChild("cube_tend1_pod", ModelPartBuilder.create().uv(92, 112).cuboid(3.00000F, -31.00000F, 22.00000F, 4.00000F, 4.00000F, 4.00000F, Dilation.NONE), ModelTransform.of(-5.00000F, 29.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        tendril_1b.addChild("cube_tend1_b", ModelPartBuilder.create().uv(78, 114).cuboid(4.00000F, -30.00000F, 16.00000F, 2.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-5.00000F, 29.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_2 = chest.addChild("tendril_2", ModelPartBuilder.create(), ModelTransform.of(-5.00000F, -6.00000F, 7.00000F, -0.20944F, 0.00000F, 0.00000F));
        tendril_2.addChild("cube_tend2_a", ModelPartBuilder.create().uv(180, 101).cuboid(-6.50000F, -30.50000F, 10.00000F, 3.00000F, 3.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(5.00000F, 29.00000F, -10.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_2b = tendril_2.addChild("tendril_2b", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 6.00000F, -0.26180F, 0.00000F, 0.00000F));
        tendril_2b.addChild("cube_tend2_pod", ModelPartBuilder.create().uv(124, 112).cuboid(-7.00000F, -31.00000F, 22.00000F, 4.00000F, 4.00000F, 4.00000F, Dilation.NONE), ModelTransform.of(5.00000F, 29.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        tendril_2b.addChild("cube_tend2_b", ModelPartBuilder.create().uv(110, 114).cuboid(-6.00000F, -30.00000F, 16.00000F, 2.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(5.00000F, 29.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_3 = chest.addChild("tendril_3", ModelPartBuilder.create(), ModelTransform.of(8.00000F, -2.00000F, 7.00000F, -0.20944F, 0.00000F, 0.00000F));
        tendril_3.addChild("cube_tend3_a", ModelPartBuilder.create().uv(198, 101).cuboid(6.50000F, -26.50000F, 10.00000F, 3.00000F, 3.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-8.00000F, 25.00000F, -10.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_3b = tendril_3.addChild("tendril_3b", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 6.00000F, -0.26180F, 0.00000F, 0.00000F));
        tendril_3b.addChild("cube_tend3_pod", ModelPartBuilder.create().uv(156, 112).cuboid(6.00000F, -27.00000F, 22.00000F, 4.00000F, 4.00000F, 4.00000F, Dilation.NONE), ModelTransform.of(-8.00000F, 25.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        tendril_3b.addChild("cube_tend3_b", ModelPartBuilder.create().uv(142, 114).cuboid(7.00000F, -26.00000F, 16.00000F, 2.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-8.00000F, 25.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_4 = chest.addChild("tendril_4", ModelPartBuilder.create(), ModelTransform.of(-8.00000F, -2.00000F, 7.00000F, -0.20944F, 0.00000F, 0.00000F));
        tendril_4.addChild("cube_tend4_a", ModelPartBuilder.create().uv(216, 101).cuboid(-9.50000F, -26.50000F, 10.00000F, 3.00000F, 3.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(8.00000F, 25.00000F, -10.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData tendril_4b = tendril_4.addChild("tendril_4b", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 0.00000F, 6.00000F, -0.26180F, 0.00000F, 0.00000F));
        tendril_4b.addChild("cube_tend4_pod", ModelPartBuilder.create().uv(188, 112).cuboid(-10.00000F, -27.00000F, 22.00000F, 4.00000F, 4.00000F, 4.00000F, Dilation.NONE), ModelTransform.of(8.00000F, 25.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        tendril_4b.addChild("cube_tend4_b", ModelPartBuilder.create().uv(174, 114).cuboid(-9.00000F, -26.00000F, 16.00000F, 2.00000F, 2.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(8.00000F, 25.00000F, -16.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_r = boss.addChild("leg_r", ModelPartBuilder.create(), ModelTransform.of(6.00000F, -18.00000F, 6.00000F, 0.00000F, 0.00000F, 0.00000F));
        leg_r.addChild("cube_thigh_r", ModelPartBuilder.create().uv(64, 86).cuboid(2.00000F, -18.00000F, -4.00000F, 8.00000F, 8.00000F, 8.00000F, Dilation.NONE), ModelTransform.of(-6.00000F, 18.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leglow_r = leg_r.addChild("leglow_r", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 8.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        leglow_r.addChild("cube_foot_r", ModelPartBuilder.create().uv(131, 89).cuboid(1.50000F, -3.00000F, -6.00000F, 9.00000F, 3.00000F, 11.00000F, Dilation.NONE), ModelTransform.of(-6.00000F, 10.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        leglow_r.addChild("cube_shin_r", ModelPartBuilder.create().uv(206, 84).cuboid(3.00000F, -10.00000F, -3.00000F, 6.00000F, 7.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(-6.00000F, 10.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leg_l = boss.addChild("leg_l", ModelPartBuilder.create(), ModelTransform.of(-6.00000F, -18.00000F, 6.00000F, 0.00000F, 0.00000F, 0.00000F));
        leg_l.addChild("cube_thigh_l", ModelPartBuilder.create().uv(96, 86).cuboid(-10.00000F, -18.00000F, -4.00000F, 8.00000F, 8.00000F, 8.00000F, Dilation.NONE), ModelTransform.of(6.00000F, 18.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        ModelPartData leglow_l = leg_l.addChild("leglow_l", ModelPartBuilder.create(), ModelTransform.of(0.00000F, 8.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        leglow_l.addChild("cube_foot_l", ModelPartBuilder.create().uv(171, 89).cuboid(-10.50000F, -3.00000F, -6.00000F, 9.00000F, 3.00000F, 11.00000F, Dilation.NONE), ModelTransform.of(6.00000F, 10.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        leglow_l.addChild("cube_shin_l", ModelPartBuilder.create().uv(230, 84).cuboid(-9.00000F, -10.00000F, -3.00000F, 6.00000F, 7.00000F, 6.00000F, Dilation.NONE), ModelTransform.of(6.00000F, 10.00000F, 0.00000F, 0.00000F, 0.00000F, 0.00000F));
        return TexturedModelData.of(modelData, 256, 256);
    }

    private final ModelPart body;
    private final ModelPart chest;
    private final ModelPart head;
    private final ModelPart cap;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart forearm_r;
    private final ModelPart forearm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;
    private final ModelPart jaw;
    private final float bodyBaseY;
    public MushroomBossModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("boss").getChild("body");
        this.chest = root.getChild("boss").getChild("body").getChild("chest");
        this.head = root.getChild("boss").getChild("body").getChild("chest").getChild("head");
        this.cap = root.getChild("boss").getChild("body").getChild("chest").getChild("head").getChild("cap");
        this.arm_r = root.getChild("boss").getChild("body").getChild("chest").getChild("arm_r");
        this.arm_l = root.getChild("boss").getChild("body").getChild("chest").getChild("arm_l");
        this.forearm_r = root.getChild("boss").getChild("body").getChild("chest").getChild("arm_r").getChild("forearm_r");
        this.forearm_l = root.getChild("boss").getChild("body").getChild("chest").getChild("arm_l").getChild("forearm_l");
        this.leg_r = root.getChild("boss").getChild("leg_r");
        this.leg_l = root.getChild("boss").getChild("leg_l");
        this.jaw = root.getChild("boss").getChild("body").getChild("chest").getChild("head").getChild("jaw");
        this.bodyBaseY = this.body.pivotY;
    }


    @Override public void setAngles(MushroomBossEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        float swing = MathHelper.cos(limbAngle * 0.72F) * 0.32F * limbDistance;
        this.leg_r.pitch = swing; this.leg_l.pitch = -swing;
        this.body.pivotY = this.bodyBaseY + MathHelper.sin(animationProgress * 0.10F) * 0.8F;
        this.chest.pitch = MathHelper.sin(animationProgress * 0.06F) * 0.035F;
        this.head.yaw = headYaw * 0.017453292F; this.head.pitch = headPitch * 0.017453292F;
        float slam = entity.getSlamTicks() > 0 ? MathHelper.sin((24 - entity.getSlamTicks()) * 0.1309F) : 0.0F;
        float enrage = entity.isEnraged() ? 0.18F : 0.0F;
        this.arm_r.pitch = -0.10F - slam * 1.55F - enrage; this.arm_l.pitch = -0.10F - slam * 1.55F - enrage;
        this.forearm_r.pitch = -slam * 0.35F; this.forearm_l.pitch = -slam * 0.35F;
        this.jaw.pitch = entity.getSlamTicks() > 0 ? 0.22F : MathHelper.sin(animationProgress * 0.08F) * 0.025F;
        this.cap.roll = MathHelper.sin(animationProgress * (entity.isEnraged() ? 0.18F : 0.07F)) * (entity.isEnraged() ? 0.16F : 0.05F);
    }

    @Override public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
        this.root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
