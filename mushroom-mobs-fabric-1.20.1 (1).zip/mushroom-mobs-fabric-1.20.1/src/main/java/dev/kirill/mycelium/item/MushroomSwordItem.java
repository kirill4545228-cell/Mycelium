package dev.kirill.mycelium.item;

import dev.kirill.mycelium.entity.MushroomBossEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class MushroomSwordItem extends SwordItem {
    public MushroomSwordItem(Settings settings) {
        super(ToolMaterials.DIAMOND, 5, -2.4F, settings.maxDamage(1100));
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean success = super.postHit(stack, target, attacker);
        if (!target.getWorld().isClient && target.getWorld().random.nextFloat() < 0.35F) {
            target.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.POISON, 60, 0), attacker);
            if (target.getWorld() instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(ParticleTypes.POOF, target.getX(), target.getBodyY(0.65), target.getZ(), 7, 0.25, 0.25, 0.25, 0.02);
            }
        }
        return success;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!user.getItemCooldownManager().isCoolingDown(this) && !world.isClient) {
            user.getItemCooldownManager().set(this, 180);
            for (var entity : world.getOtherEntities(user, user.getBoundingBox().expand(4.5), e -> e instanceof HostileEntity)) {
                if (entity instanceof LivingEntity target) {
                    target.damage(user.getDamageSources().playerAttack(user), 4.0F);
                    target.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.POISON, 50, 0), user);
                    target.takeKnockback(0.65, user.getX() - target.getX(), user.getZ() - target.getZ());
                }
            }
            if (world instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(ParticleTypes.POOF, user.getX(), user.getBodyY(0.5), user.getZ(), 36, 1.8, 0.45, 1.8, 0.04);
            }
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
