package dev.kirill.mycelium.client.render;

import dev.kirill.mycelium.MyceliumMod;
import dev.kirill.mycelium.client.model.MushroomBossModel;
import dev.kirill.mycelium.entity.MushroomBossEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class MushroomBossRenderer extends MobEntityRenderer<MushroomBossEntity, MushroomBossModel> {
    private static final Identifier TEXTURE = new Identifier(MyceliumMod.MOD_ID, "textures/entity/mushroom_boss.png");
    public MushroomBossRenderer(EntityRendererFactory.Context context) {
        super(context, new MushroomBossModel(context.getPart(dev.kirill.mycelium.client.MyceliumClient.BOSS_LAYER)), 0.9F);
    }
    @Override public Identifier getTexture(MushroomBossEntity entity) { return TEXTURE; }
}
