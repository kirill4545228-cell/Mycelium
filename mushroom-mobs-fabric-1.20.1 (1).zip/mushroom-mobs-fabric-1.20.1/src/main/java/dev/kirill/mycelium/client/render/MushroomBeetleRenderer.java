package dev.kirill.mycelium.client.render;

import dev.kirill.mycelium.MyceliumMod;
import dev.kirill.mycelium.client.model.MushroomBeetleModel;
import dev.kirill.mycelium.entity.MushroomBeetleEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class MushroomBeetleRenderer extends MobEntityRenderer<MushroomBeetleEntity, MushroomBeetleModel> {
    private static final Identifier TEXTURE = new Identifier(MyceliumMod.MOD_ID, "textures/entity/mushroom_beetle.png");
    public MushroomBeetleRenderer(EntityRendererFactory.Context context) {
        super(context, new MushroomBeetleModel(context.getPart(dev.kirill.mycelium.client.MyceliumClient.BEETLE_LAYER)), 0.35F);
    }
    @Override public Identifier getTexture(MushroomBeetleEntity entity) { return TEXTURE; }
}
